// script 태그로 감싸져있음
function test(){
    window.alert('별도로 작성된 js 파일!');
}